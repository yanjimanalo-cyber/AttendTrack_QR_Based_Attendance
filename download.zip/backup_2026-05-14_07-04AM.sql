-- ============================================================
-- AttendTrack Auto Backup
-- Generated: 2026-05-14 07:04:10
-- Server: sql307.infinityfree.com via TCP/IP
-- ============================================================

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET time_zone='+00:00';

-- ── Table: attendance ──────────────────────────────────────────
DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `status` enum('Present','Late','Absent') DEFAULT 'Present',
  `date` date NOT NULL,
  `time_in` time NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `no_duplicate` (`student_id`,`date`),
  KEY `session_id` (`session_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `attendance` VALUES
('1', '1', '1', 'Present', '2026-05-14', '06:50:45');

-- ── Table: device_locks ──────────────────────────────────────────
DROP TABLE IF EXISTS `device_locks`;
CREATE TABLE `device_locks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fingerprint` varchar(128) NOT NULL,
  `student_id` int(11) NOT NULL,
  `locked_date` date NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_device_date` (`fingerprint`,`locked_date`),
  KEY `student_id` (`student_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `device_locks` VALUES
('1', 'fp_ui9ks7_31', '1', '2026-05-14', '2026-05-14 03:50:45'),
('2', 'fp_8liyit_2y', '1', '2026-05-14', '2026-05-14 03:54:12');

-- ── Table: qr_sessions ──────────────────────────────────────────
DROP TABLE IF EXISTS `qr_sessions`;
CREATE TABLE `qr_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL,
  `token` varchar(64) NOT NULL,
  `start_time` datetime NOT NULL,
  `present_until` datetime NOT NULL,
  `late_until` datetime NOT NULL,
  `session_end` datetime NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `section_id` (`section_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `qr_sessions` VALUES
('1', '2', '7ff241ece86095775481549a595a81880ecac685850e489d909ffe856d57a8af', '2026-05-14 06:50:06', '2026-05-14 07:05:06', '2026-05-14 07:15:06', '2026-05-14 07:50:06', '2026-05-14 03:50:06');

-- ── Table: sections ──────────────────────────────────────────
DROP TABLE IF EXISTS `sections`;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `sections` VALUES
('2', 'BSINFO2B', '2026-05-14 03:49:32');

-- ── Table: students ──────────────────────────────────────────
DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `school_id` varchar(50) NOT NULL,
  `section_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `school_id` (`school_id`),
  KEY `section_id` (`section_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `students` VALUES
('1', 'Gian Karl Manalo', '0324-0425', '2', '2026-05-14 03:49:46'),
('2', 'Jerwin Tito', '0324-0477', '2', '2026-05-14 03:50:03');

-- ── Table: system_logs ──────────────────────────────────────────
DROP TABLE IF EXISTS `system_logs`;
CREATE TABLE `system_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_event` (`event_type`),
  KEY `idx_created` (`created_at`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `system_logs` VALUES
('1', 'auto_backup', 'Auto backup created: backup_2026-05-14_06-47AM.sql (4,506 bytes)', '1', '180.195.38.101', '2026-05-14 03:47:46'),
('2', 'logout', 'Teacher \'Gian Karl Manalo\' signed out', '1', '180.195.38.101', '2026-05-14 03:47:50'),
('3', 'login_failed', 'Failed login attempt for email: siryes@gmail.com from 180.195.38.101', NULL, '180.195.38.101', '2026-05-14 03:48:14'),
('4', 'auto_backup', 'Auto backup created: backup_2026-05-14_06-48AM.sql (4,941 bytes)', NULL, '180.195.38.101', '2026-05-14 03:48:14'),
('5', 'login', 'Teacher \'Kerwin Vargas\' logged in from 180.195.38.101', '1', '180.195.38.101', '2026-05-14 03:49:05'),
('6', 'auto_backup', 'Auto backup created: backup_2026-05-14_06-49AM.sql (5,394 bytes)', '1', '180.195.38.101', '2026-05-14 03:49:05'),
('7', 'auto_backup', 'Auto backup created: backup_2026-05-14_06-50AM.sql (5,799 bytes)', '1', '180.195.38.101', '2026-05-14 03:50:03'),
('8', 'attendance', 'Student \'Gian Karl Manalo\' marked Present via QR scan at 06:50 AM', NULL, '180.195.38.101', '2026-05-14 03:50:45'),
('9', 'auto_backup', 'Auto backup created: backup_2026-05-14_06-51AM.sql (6,541 bytes)', NULL, '180.195.38.101', '2026-05-14 03:51:16'),
('10', 'auto_backup', 'Auto backup created: backup_2026-05-14_06-53AM.sql (6,679 bytes)', NULL, '180.195.38.101', '2026-05-14 03:53:52'),
('11', 'auto_backup', 'Auto backup created: backup_2026-05-14_06-54AM.sql (6,817 bytes)', NULL, '180.195.38.101', '2026-05-14 03:54:08');

-- ── Table: users ──────────────────────────────────────────
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `school_id` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `school_id` (`school_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `users` VALUES
('1', 'Kerwin Vargas', '0324-0456', 'kerwinVargas@gmail.com', '$2y$10$s0QZ7yQqffaQbmGui8QG9OJMNcrhLuS7MqtwlitiBRwpha5bcTeve', '2026-05-14 03:48:54');

SET FOREIGN_KEY_CHECKS=1;
